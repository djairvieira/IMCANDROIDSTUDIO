package projetoead.com.djair_vieira;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.text.DecimalFormat;

public class MainActivity extends Activity implements OnClickListener {


    /** Called when the activity is first created. */
        @Override
        public void onCreate(Bundle icicle) {
            super.onCreate(icicle);
            setContentView(R.layout.main);

            //Ação do botão
            Button calc = (Button) findViewById(R.id.btCalcular);
            calc.setOnClickListener(this);
        }
        public void onClick(View v){

            //Conversão  para o formato 0.00
            DecimalFormat fmt = new DecimalFormat("0.00");

            //Variaveis
            final EditText altura = (EditText) findViewById(R.id.etAltura);
            final EditText peso = (EditText) findViewById(R.id.etPeso);
            final EditText idade = (EditText) findViewById(R.id.etIdade);
            final  EditText sexo = (EditText) findViewById(R.id.etSexo);

            double alt = Double.parseDouble(altura.getText().toString());
            double pes = Double.parseDouble(peso.getText().toString());
            double ida = Double.parseDouble(idade.getText().toString());
            double sex = Double.parseDouble(sexo.getText().toString());


            // Calculo do IMC e do indice de percentual de gordura
            String valor = fmt.format((1.20 * pes / (alt * alt)) + (0.23 * ida) - (10.8 * sex) - 5.4);
            String valor1 = fmt.format((1.20 * 22) + (0.23 * 27)-(10.8 * 0)-5.41);


            String imc = fmt.format(pes / (alt * alt));
            double imcNum = pes / (alt * alt);
            double valorNum = ((1.20 * pes / (alt * alt)) + (0.23 * ida) - (10.8 * sex) - 5.4);
            double valorNum1 = ((1.20 * 22) + (0.23 * 27)-(10.8 * 0)-5.41);


            //Mostrará o resultado na tela do User
            Toast.makeText(this, "Seu IMC é:\n      " + imc, Toast.LENGTH_LONG).show();
            Toast.makeText(this, "Sua % de gordura é:\n \n \n                 " + valor, Toast.LENGTH_LONG).show();
            Toast.makeText(this, "Sua % de gordura 2 é:\n \n \n \n \n \n \n \n \n \n \n                 " + valor1, Toast.LENGTH_LONG).show();
        }
    }